# Operação de produção

## Rollback

1. Pare o tráfego para a versão nova.
2. Reponha a imagem ou artefacto da última versão aprovada.
3. Não reverta migrações destrutivas; migrações deste projeto são aditivas.
4. Execute `npm run backup:postgres:verify` antes de reabrir tráfego.
5. Confirme `/api/health`, login, compra e validação de bilhetes.

## Jobs assíncronos

`async_jobs` suporta notificações, webhooks, exportações, backups e reconciliação.
Cada job pode usar `idempotency_key`, tem cinco tentativas por padrão, backoff
exponencial e estado `dead_letter` após esgotar as tentativas. O worker é
executado com `npm run worker`; handlers de integração devem ser ativados apenas
quando o respetivo fornecedor estiver configurado.
