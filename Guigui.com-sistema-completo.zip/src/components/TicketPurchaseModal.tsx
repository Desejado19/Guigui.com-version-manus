import React, { useState } from 'react';
import {
  MapPin,
  Calendar,
  ChevronDown,
  ShieldCheck,
  X,
} from 'lucide-react';
import { Button } from './ui/Button';
import { IconButton } from './ui/IconButton';

interface TicketPurchaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (data: {
    category: string;
    quantity: number;
    buyerName: string;
    buyerPhone: string;
    paymentMethod: 'orange' | 'telecel' | 'manual';
    policyAccepted: boolean;
    policyVersion: string;
    policyAcceptedAt: string;
  }) => void;
}

export const TicketPurchaseModal: React.FC<TicketPurchaseModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [buyerName, setBuyerName] = useState('Desejado Manuel Barbosa');
  const [buyerPhone, setBuyerPhone] = useState('956338807');
  const [paymentMethod, setPaymentMethod] = useState<'orange' | 'telecel' | 'manual'>('manual');
  const [isTitleHolderOther, setIsTitleHolderOther] = useState(false);
  const [policyAccepted, setPolicyAccepted] = useState(false);

  const category = 'Entrada Geral';
  const categoryPrice = 2500;
  const platformFee = 450;
  const total = categoryPrice * quantity;

  const POLICY_VERSION = '1.0';

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      role="dialog"
      aria-modal="true"
      aria-label="Compra de bilhete"
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div
        className="ticket-purchase-modal ticket-surface relative w-full max-w-sm mx-2 transform rounded-[var(--radius-2xl)] bg-white shadow-[var(--shadow-lg)] flex flex-col animate-in fade-in zoom-in duration-300 max-h-[88vh] overflow-y-auto"
      >
        {/* Header - Dark Green */}
        <div className="ticket-purchase-header relative overflow-hidden rounded-t-[var(--radius-2xl)] bg-gradient-to-b from-[var(--color-bg-surface)] to-[var(--color-green-950)] px-4 py-3 text-white">
          {/* Close button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full border border-[var(--color-green-700)] bg-[var(--color-bg-surface)] text-[var(--color-text-muted)] flex items-center justify-center hover:border-[var(--color-green-500)] hover:bg-[var(--color-green-950)] hover:text-white transition-colors"
            aria-label="Fechar"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Badge */}
          <div className="flex items-center gap-1.5 mb-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--color-green-500)]" />
            <span className="text-[10px] font-semibold text-[var(--color-green-500)] uppercase tracking-wider">
              Compra de Bilhete
            </span>
          </div>

          <h1 className="text-xl font-bold leading-tight mb-1">
            Mercado Central de Bissau apresenta: Agend..
          </h1>
          <p className="text-xs text-[var(--color-text-muted)] mb-4">
            Mercado Central de Bissau
          </p>

          {/* Info row */}
          <div className="flex items-center gap-3 text-[11px] text-[var(--color-text-muted)]">
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3 h-3 text-[var(--color-green-500)]" />
              <span>Avenida Principal, Bissau Velho, Bissau</span>
            </div>
            <div className="w-px h-3 bg-[var(--color-green-900)] mx-1" />
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3 h-3 text-[var(--color-green-500)]" />
              <span>2026-10-01, 18:00 - 23:00</span>
            </div>
          </div>
        </div>

        {/* Steps Content */}
        <div className="p-4 space-y-4 bg-white">
          {/* Step 1: Categoria */}
          <div className="flex items-start gap-3">
            <div className="flex-shrink-0 w-6 h-6 rounded-full bg-[var(--color-green-500)]/10 flex items-center justify-center text-[10px] font-bold text-[var(--color-green-500)] border border-[var(--color-green-500)]/30">
              1
            </div>
            <div>
              <h3 className="text-sm font-bold text-[var(--color-text-strong)]">Categoria</h3>
              <div className="ticket-category-list mt-2">
                <div
                  className="ticket-category-option flex items-center justify-between px-3 py-2.5 rounded-xl border border-[var(--color-green-900)] bg-[var(--color-bg-surface)]/5 cursor-pointer hover:border-[var(--color-green-500)] hover:bg-[var(--color-green-950)]/30 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-[var(--color-text-default)]">Entrada Geral</span>
                    <span className="text-[10px] text-[var(--color-text-muted)]">Disponíveis: 180 bilhetes</span>
                  </div>
                  <span className="text-base font-bold text-[var(--color-green-500)]">2500 XOF</span>
                </div>
              </div>
            </div>
          </div>

          {/* Step 2: Quantidade */}
          <div className="flex items-start gap-3 pt-2 border-t border-[var(--color-green-900)]/20">
            <div className="flex-shrink-0 w-6 h-6 rounded-full bg-[var(--color-green-500)]/10 flex items-center justify-center text-[10px] font-bold text-[var(--color-green-500)] border border-[var(--color-green-500)]/30 mt-0.5">
              2
            </div>
            <div>
              <h3 className="text-sm font-bold text-[var(--color-text-strong)]">Quantidade</h3>
              <div className="mt-2 flex items-center justify-between">
                <span className="text-xs text-[var(--color-text-muted)]">Número de bilhetes</span>
                <div className="flex items-center gap-1 rounded-xl border border-[var(--color-green-900)]/30 bg-[var(--color-bg-subtle)] px-2 py-1.5">
                  <button
                    type="button"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    disabled={quantity <= 1}
                    className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-[var(--color-text-muted)] hover:text-[var(--color-green-500)] disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    −
                  </button>
                  <span className="text-sm font-semibold text-[var(--color-text-strong)]">{quantity}</span>
                  <button
                    type="button"
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-[var(--color-text-muted)] hover:text-[var(--color-green-500)]"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Step 3: Dados do comprador */}
          <div className="flex items-start gap-3 pt-2 border-t border-[var(--color-green-900)]/20">
            <div className="flex-shrink-0 w-6 h-6 rounded-full bg-[var(--color-green-500)]/10 flex items-center justify-center text-[10px] font-bold text-[var(--color-green-500)] border border-[var(--color-green-500)]/30 mt-0.5">
              3
            </div>
            <div>
              <h3 className="text-sm font-bold text-[var(--color-text-strong)]">Dados do comprador</h3>
              <div className="mt-2 grid grid-cols-2 gap-3">
                <div className="ticket-buyer-fields">
                  <label className="block text-[10px] text-[var(--color-text-muted)] mb-1">Nome completo</label>
                  <input
                    type="text"
                    value={buyerName}
                    onChange={(e) => setBuyerName(e.target.value)}
                    className="w-full min-h-[40px] rounded-xl border border-[var(--color-green-900)]/30 bg-[var(--color-bg-subtle)] px-3 text-sm text-[var(--color-text-strong)] outline-none focus:border-[var(--color-green-500)]"
                    placeholder="Nome completo"
                  />
                </div>
                <div className="ticket-buyer-fields">
                  <label className="block text-[10px] text-[var(--color-text-muted)] mb-1">Número de telefone</label>
                  <input
                    type="tel"
                    value={buyerPhone}
                    onChange={(e) => setBuyerPhone(e.target.value)}
                    className="w-full min-h-[40px] rounded-xl border border-[var(--color-green-900)]/30 bg-[var(--color-bg-subtle)] px-3 text-sm text-[var(--color-text-strong)] outline-none focus:border-[var(--color-green-500)]"
                    placeholder="Número de telefone"
                  />
                </div>
              </div>
              <div className="mt-3">
                <div className="ticket-buyer-fields flex items-center justify-between px-3 py-2.5 rounded-xl border border-[var(--color-green-900)]/30 bg-[var(--color-bg-subtle)] cursor-pointer">
                  <span className="text-xs text-[var(--color-text-muted)]">Titular do bilhete é outra pessoa</span>
                  <ChevronDown className="w-4 h-4 text-[var(--color-text-muted)]" />
                </div>
              </div>
              {isTitleHolderOther && (
                <div className="mt-3 grid grid-cols-2 gap-3">
                  <div className="ticket-buyer-fields">
                    <label className="block text-[10px] text-[var(--color-text-muted)] mb-1">Nome do titular</label>
                    <input
                      type="text"
                      className="w-full min-h-[40px] rounded-xl border border-[var(--color-green-900)]/30 bg-[var(--color-bg-subtle)] px-3 text-sm text-[var(--color-text-strong)] outline-none focus:border-[var(--color-green-500)]"
                      placeholder="Nome do titular"
                    />
                  </div>
                  <div className="ticket-buyer-fields">
                    <label className="block text-[10px] text-[var(--color-text-muted)] mb-1">Telefone do titular</label>
                    <input
                      type="tel"
                      className="w-full min-h-[40px] rounded-xl border border-[var(--color-green-900)]/30 bg-[var(--color-bg-subtle)] px-3 text-sm text-[var(--color-text-strong)] outline-none focus:border-[var(--color-green-500)]"
                      placeholder="Telefone do titular"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Step 4: Método de pagamento */}
          <div className="flex items-start gap-3 pt-2 border-t border-[var(--color-green-900)]/20">
            <div className="flex-shrink-0 w-6 h-6 rounded-full bg-[var(--color-green-500)]/10 flex items-center justify-center text-[10px] font-bold text-[var(--color-green-500)] border border-[var(--color-green-500)]/30 mt-0.5">
              4
            </div>
            <div>
              <h3 className="text-sm font-bold text-[var(--color-text-strong)]">Método de pagamento</h3>
              <div className="mt-2 grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('orange')}
                  className={`flex flex-col items-center gap-2 px-3 py-2.5 rounded-xl border cursor-pointer transition-colors ${
                    paymentMethod === 'orange'
                      ? 'border-[var(--color-gold-500)] bg-[var(--color-gold-900)]/50 text-[var(--color-gold-500)]'
                      : 'border-[var(--color-green-900)]/30 bg-[var(--color-bg-subtle)] text-[var(--color-text-muted)] hover:border-[var(--color-green-500)]'
                  }`}
                >
                  <span className="text-[10px]">📱</span>
                  <span className="text-[10px] font-medium">Orange Money Bissau</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('telecel')}
                  className={`flex flex-col items-center gap-2 px-3 py-2.5 rounded-xl border cursor-pointer transition-colors ${
                    paymentMethod === 'telecel'
                      ? 'border-[var(--color-blue-400)] bg-[var(--color-blue-900)]/50 text-[var(--color-blue-400)]'
                      : 'border-[var(--color-green-900)]/30 bg-[var(--color-bg-subtle)] text-[var(--color-text-muted)] hover:border-[var(--color-green-500)]'
                  }`}
                >
                  <span className="text-[10px]">📱</span>
                  <span className="text-[10px] font-medium">Telecel Bissau</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('manual')}
                  className={`flex flex-col items-center gap-2 px-3 py-2.5 rounded-xl border cursor-pointer transition-colors ${
                    paymentMethod === 'manual'
                      ? 'border-[var(--color-green-500)] bg-[var(--color-green-500)]/10 text-[var(--color-green-500)] ring-1 ring-[var(--color-green-500)]'
                      : 'border-[var(--color-green-900)]/30 bg-[var(--color-bg-subtle)] text-[var(--color-text-muted)] hover:border-[var(--color-green-500)]'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span className="text-[10px] font-medium">Transferência manual</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer - Summary & Confirm */}
        <div className="p-4 border-t border-[var(--color-green-900)]/20 bg-[var(--color-bg-subtle)]">
          <div className="ticket-payment-summary mb-4">
            <div className="flex justify-between text-[10px] text-[var(--color-text-muted)] mb-1">
              <span>Taxas da plataforma (retidas da empresa)</span>
              <span>{platformFee} XOF</span>
            </div>
            <div className="ticket-receipt-line mb-3">
              <div className="flex justify-between text-sm font-bold text-[var(--color-text-strong)]">
                <span>Total a pagar</span>
                <span className="text-[var(--color-green-500)]">{total} XOF</span>
              </div>
            </div>
          </div>

          {/* Política de bilhética - Regra 3.4 e 6.4 */}
          <div className="mb-4 p-3 rounded-xl border border-[var(--color-border-subtle)] bg-[var(--color-bg-surface)]">
            <p className="text-[10px] font-bold uppercase tracking-wider text-[var(--color-text-muted)] mb-2">
              Política de Compra de Bilhetes (v{POLICY_VERSION})
            </p>
            <p className="text-[10px] leading-relaxed text-[var(--color-text-muted)] mb-3">
              Ao comprar, confirma que leu e aceita a política de bilhética da Guigui.com.
              A compra é definitiva após confirmação do pagamento. Não há cancelamento
              voluntário nem reembolso por motivos pessoais (Regra 6). Exceções apenas
              por erro de pagamento ou cancelamento de evento pelo organizador.
            </p>
            <div className="flex items-start gap-2">
              <input
                type="checkbox"
                checked={policyAccepted}
                onChange={(e) => setPolicyAccepted(e.target.checked)}
                className="h-4 w-4 mt-0.5 rounded border-[var(--color-border-subtle)] bg-[var(--color-bg-surface)] text-[var(--color-green-600)] focus:ring-2 focus:ring-[var(--color-green-600)]"
                required
              />
              <label className="text-[10px] leading-relaxed text-[var(--color-text-strong)] cursor-pointer">
                Li e aceito a política de bilhética da Guigui.com (versão {POLICY_VERSION})
              </label>
            </div>
          </div>

          <Button
            variant="primary"
            size="md"
            className="w-full min-h-[44px] rounded-xl bg-[var(--color-green-500)] text-white font-bold hover:bg-[var(--color-green-700)] transition-colors flex items-center justify-center gap-2"
            onClick={() => {
              onConfirm({
                category,
                quantity,
                buyerName,
                buyerPhone,
                paymentMethod,
                policyAccepted,
                policyVersion: POLICY_VERSION,
                policyAcceptedAt: new Date().toISOString(),
              });
            }}
            disabled={!policyAccepted}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Confirmar e Pagar {total} XOF</span>
          </Button>
        </div>
      </div>
    </div>
  );
};

TicketPurchaseModal.displayName = 'TicketPurchaseModal';



