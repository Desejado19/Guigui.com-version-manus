import React from 'react';
import {
  MapPin,
  MessageCircle,
  Phone,
  UserPlus,
  UserCheck,
  CheckCircle2,
  Award,
  ChevronRight,
  Sparkles,
  CheckSquare,
  Square,
  Bell,
  BellOff,
} from 'lucide-react';
import { Business, Language } from '../types';
import { getTranslation } from '../utils/i18n';
import { useTranslatedText } from '../utils/contentTranslation';
import { Badge, Card } from './ui';

interface BusinessCardProps {
  business: Business;
  currentLang: Language;
  onSelect: (b: Business) => void;
  onToggleCompare?: (b: Business) => void;
  isCompared?: boolean;
  compareDisabled?: boolean;
  isFollowed?: boolean;
  onToggleFollow?: (businessId: string) => void;
  onToggleNotifications?: (businessId: string) => void;
  notificationsMuted?: boolean;
  onMessage?: (businessId: string) => void;
  onContactMetric?: (businessId: string, metric: 'phoneClicks' | 'whatsappClicks' | 'directionsClicks' | 'websiteClicks') => void;
}

export const BusinessCard: React.FC<BusinessCardProps> = ({
  business,
  currentLang,
  onSelect,
  onToggleCompare,
  isCompared = false,
  compareDisabled = false,
  isFollowed = false,
  onToggleFollow,
  onToggleNotifications,
  notificationsMuted = false,
  onMessage,
  onContactMetric,
}) => {
  const t = (key: string) => getTranslation(currentLang, key);
  const { translated: description } = useTranslatedText(business.description, currentLang, 'description');

  const isEnterprise = business.tier === 'enterprise';
  const isPremium = business.tier === 'premium';
  const hasActivePromo = business.promotions.some((p) => p.isActive);
  const priceDots = business.priceRange?.repeat(1) ?? '';

  return (
    <Card interactive className="guigui-business-card group flex flex-col justify-between">
      {/* Cover Image & Badges */}
      <div className="relative w-full cursor-pointer" onClick={() => onSelect(business)}>
        <div className="guigui-business-cover relative w-full h-[160px] overflow-hidden">
          <img
            src={business.coverImage || 'https://images.unsplash.com/photo-1543062447-aa5c839cdc5d?w=800&q=80'}
            alt={business.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0d2924]/70 via-transparent to-transparent" />

          {/* Tier / Highlight Badge — topo esquerdo */}
          {(isEnterprise || isPremium) && (
            <Badge variant={isEnterprise ? 'verified' : 'premium'} className="absolute top-4 left-4 shadow-lg uppercase tracking-wider">
              <Sparkles className="w-3 h-3 text-gold-300" />
              <span>{isEnterprise ? t('featured') : t('tierPremium')}</span>
            </Badge>
          )}

          {/* Open/Closed Badge — topo direito */}
          <Badge variant={business.isOpenNow ? 'success' : 'neutral'} className="absolute top-4 right-4 shadow-lg backdrop-blur-md">
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                business.isOpenNow ? 'bg-[var(--color-state-success)] animate-pulse' : 'bg-[var(--color-text-muted)]'
              }`}
            />
            <span>{business.isOpenNow ? t('openNow') : t('closedNow')}</span>
          </Badge>

          {/* Active Promo Tag — canto inferior direito da capa */}
          {hasActivePromo && (
            <Badge variant="premium" className="absolute bottom-4 right-4 shadow-lg">
              {t('activeOffer')}
            </Badge>
          )}

          {/* Comparison Checkbox — canto inferior esquerdo da capa */}
          {onToggleCompare && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleCompare(business);
              }}
              disabled={compareDisabled && !isCompared}
              className={`absolute bottom-4 left-4 z-10 text-[11px] font-extrabold px-2.5 py-1 rounded-xl shadow-lg backdrop-blur-md flex items-center gap-1.5 transition ${
                isCompared
                  ? 'bg-[var(--color-blue-600)] text-white ring-2 ring-[var(--color-blue-400)]'
                  : compareDisabled
                  ? 'bg-[rgba(13,41,36,0.6)] text-[var(--color-text-muted)] cursor-not-allowed'
                  : 'bg-[rgba(13,41,36,0.8)] text-white hover:bg-[var(--color-green-900)]'
              }`}
              title={isCompared ? t('removeFromComparison') : t('compareBusinesses')}
              aria-label={isCompared ? t('removeFromComparison') : t('compareBusinesses')}
            >
              {isCompared ? (
                <CheckSquare className="w-3.5 h-3.5 text-blue-300" />
              ) : (
                <Square className="w-3.5 h-3.5 text-slate-300" />
              )}
              <span>{isCompared ? t('comparing') : t('compare')}</span>
            </button>
          )}
        </div>

        {/* Logo overlay sobre a capa — canto inferior esquerdo */}
        <div className="absolute -bottom-6 left-4 z-10 w-14 h-14 rounded-[var(--radius-2xl)] border-2 border-white bg-white overflow-hidden shadow-lg">
          <img src={business.logo || business.coverImage} alt="" className="w-full h-full object-cover" />
        </div>





      </div>

      {/* Card Content */}
      <div className="guigui-business-content flex-1 flex flex-col space-y-4 p-5">
        {/* Business Title & Verified Check */}
        <div className="flex items-start justify-between gap-2 cursor-pointer group" onClick={() => onSelect(business)}>
          <h3 className="font-black text-lg text-[var(--color-text-strong)] leading-tight group-hover:text-[var(--color-green-600)] transition-colors line-clamp-1">
            {business.name}
          </h3>
          {business.verified && (
            <CheckCircle2
              className="w-4 h-4 text-[var(--color-green-600)] fill-[var(--color-green-600)] shrink-0 mt-0.5"
              aria-label={t('verifiedBadge')}
            />
          )}
        </div>

          {/* Location & Subcategory */}
        <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-[var(--color-text-muted)]">
          <span className="flex items-center gap-1 text-[var(--color-green-700)] font-semibold">
            <MapPin className="w-3.5 h-3.5 text-[var(--color-green-600)]" />
              {business.neighborhood}
            </span>
            <span className="h-3 w-[1px] bg-[var(--color-border-subtle)] mx-1" />
            <span className="text-[var(--color-text-default)] font-medium">{business.subcategoryId}</span>
          </div>

        {/* Description */}
        <p className="mt-1 text-sm text-[var(--color-text-default)] line-clamp-3 leading-relaxed">
          {description}
        </p>

        {/* Rating, Price & Reviews */}
        <div className="mt-2 flex items-center justify-between gap-3 px-2 py-2 rounded-xl border border-[var(--color-border-subtle)] bg-[var(--color-bg-subtle)]">
          <div className="flex items-center gap-1.5">
            <Award className="w-3.5 h-3.5 text-[var(--color-blue-600)]" />
            <span className="font-extrabold text-[var(--color-text-strong)]">{business.ratingLabel}</span>
          </div>
          {priceDots && (
            <span className="text-xs font-medium text-[var(--color-text-muted)] tracking-wide">
              {priceDots}
            </span>
          )}
          <span className="text-[var(--color-text-muted)] text-[11px] font-medium">
            {business.reviewsCount} {t('reviewsCount')}
          </span>
        </div>
      </div>

      {/* Card Action Buttons */}
      <div className="guigui-business-actions flex items-center gap-2 p-4 border-t border-[var(--color-border-subtle)] bg-[var(--color-bg-surface)]">
          {/* Follow + notification bell */}
          {onToggleFollow && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleFollow(business.id);
              }}
              className={`contact ${isFollowed ? 'bg-[var(--color-green-50)] text-[var(--color-green-700)] border-[var(--color-green-200)]' : 'bg-[var(--color-bg-subtle)] text-[var(--color-text-muted)] border-[var(--color-border-subtle)]'}`}
              title={isFollowed ? t('unfollowBusiness') : t('followBusiness')}
              aria-label={isFollowed ? `Deixar de seguir ${business.name}` : `Seguir ${business.name}`}
            >
              {isFollowed ? <UserCheck className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
            </button>
          )}
          {onToggleNotifications && isFollowed && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleNotifications(business.id);
              }}
              className={`contact ${notificationsMuted ? 'bg-[var(--color-bg-subtle)] text-[var(--color-text-muted)] border-[var(--color-border-subtle)]' : 'bg-[var(--color-gold-50)] text-[var(--color-gold-700)] border-[var(--color-gold-200)]'}`}
              title={notificationsMuted ? t('enableBusinessNotifications') : t('disableBusinessNotifications')}
              aria-label={notificationsMuted ? `Activar notificações de ${business.name}` : `Desactivar notificações de ${business.name}`}
            >
              {notificationsMuted ? <BellOff className="w-4 h-4" /> : <Bell className="w-4 h-4" />}
            </button>
          )}

          {/* Internal business message */}
          {onMessage && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onMessage(business.id);
              }}
              className="contact bg-[var(--color-bg-subtle)] text-[var(--color-text-muted)] border-[var(--color-border-subtle)] hover:bg-[var(--color-green-50)] hover:text-[var(--color-green-700)] hover:border-[var(--color-green-200)] transition-colors"
              title={`${t('sendInternalMessage')} ${business.name}`}
              aria-label={`${t('sendInternalMessage')} ${business.name}`}
            >
              <MessageCircle className="w-4 h-4" />
            </button>
          )}

          {/* Phone Call */}
          <a
            href={`tel:${business.phone}`}
            onClick={(e) => { e.stopPropagation(); onContactMetric?.(business.id, 'phoneClicks'); }}
            className="contact bg-[var(--color-bg-subtle)] text-[var(--color-text-muted)] border-[var(--color-border-subtle)] hover:bg-[var(--color-green-50)] hover:text-[var(--color-green-700)] hover:border-[var(--color-green-200)] transition-colors"
            title={t('callPhone')}
          >
            <Phone className="w-4 h-4" />
          </a>

          {/* View Profile */}
          <button type="button"
            onClick={() => onSelect(business)}
            className="view flex-1 bg-[var(--ink)] text-white hover:bg-[var(--color-green-800)] transition-colors"
          >
            <span>{t('viewProfile')}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
    </Card>
  );
};

