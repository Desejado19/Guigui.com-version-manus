import nodemailer from 'nodemailer';

const smtpHost = process.env.SMTP_HOST?.trim();
const smtpPort = Number(process.env.SMTP_PORT || 587);
const smtpUser = process.env.SMTP_USER?.trim();
const smtpPassword = process.env.SMTP_PASSWORD;
const emailFrom = process.env.EMAIL_FROM?.trim() || smtpUser;
const appUrl = process.env.APP_URL?.trim() || 'http://localhost:3000';

const transporter = smtpHost && smtpUser && smtpPassword && emailFrom
  ? nodemailer.createTransport({
      host: smtpHost,
      port: smtpPort,
      secure: process.env.SMTP_SECURE === 'true' || smtpPort === 465,
      auth: { user: smtpUser, pass: smtpPassword },
    })
  : null;

export async function sendTeamInvitation(input: {
  recipientEmail: string;
  recipientName: string;
  businessName: string;
  roleLabel: string;
  token: string;
}) {
  if (!transporter || !emailFrom) {
    throw new Error('O envio de e-mail não está configurado. Defina SMTP_HOST, SMTP_USER, SMTP_PASSWORD e EMAIL_FROM.');
  }

  const inviteUrl = `${appUrl}/?team_invite=${encodeURIComponent(input.token)}`;
  await transporter.sendMail({
    from: emailFrom,
    to: input.recipientEmail,
    subject: `Convite para colaborar com ${input.businessName}`,
    text: `Olá ${input.recipientName},\n\nFoi convidado para colaborar com ${input.businessName} como ${input.roleLabel}.\n\nAceite o convite: ${inviteUrl}\n\nSe não reconhece este convite, ignore este e-mail.`,
    html: `<p>Olá ${input.recipientName},</p><p>Foi convidado para colaborar com <strong>${input.businessName}</strong> como <strong>${input.roleLabel}</strong>.</p><p><a href="${inviteUrl}">Aceitar convite</a></p><p>Se não reconhece este convite, ignore este e-mail.</p>`,
  });
}
