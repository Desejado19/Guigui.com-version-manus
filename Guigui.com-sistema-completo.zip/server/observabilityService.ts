import { databasePool } from './db';

export async function persistRequestMetric(route: string, statusCode: number, durationMs: number): Promise<void> {
  if (!databasePool) return;
  await databasePool.query(
    `INSERT INTO request_metrics (metric_date,route,request_count,error_count,total_duration_ms)
     VALUES (CURRENT_DATE,$1,1,$2,$3)
     ON CONFLICT (metric_date,route) DO UPDATE SET request_count=request_metrics.request_count+1,
       error_count=request_metrics.error_count+EXCLUDED.error_count,
       total_duration_ms=request_metrics.total_duration_ms+EXCLUDED.total_duration_ms,
       updated_at=NOW()`,
    [route.slice(0, 255), statusCode >= 400 ? 1 : 0, Math.round(durationMs)],
  );
}

export async function getDatabaseObservability(): Promise<{ metricsDate: string; requests: number; errors: number } | null> {
  if (!databasePool) return null;
  const result = await databasePool.query(
    `SELECT CURRENT_DATE::text AS "metricsDate", COALESCE(SUM(request_count),0)::int AS requests,
      COALESCE(SUM(error_count),0)::int AS errors FROM request_metrics WHERE metric_date=CURRENT_DATE`,
  );
  return result.rows[0] || null;
}
