import { getDatabaseObservability } from './observabilityService';

export async function renderPrometheusMetrics(requestTotal: number, requestErrors: number, routes: Map<string, { count: number; errors: number; totalMs: number }>): Promise<string> {
  const database = await getDatabaseObservability();
  const lines = [
    '# HELP guigui_http_requests_total Total HTTP requests observed by this process.',
    '# TYPE guigui_http_requests_total counter',
    `guigui_http_requests_total ${requestTotal}`,
    '# HELP guigui_http_errors_total Total HTTP responses with status 500 or higher.',
    '# TYPE guigui_http_errors_total counter',
    `guigui_http_errors_total ${requestErrors}`,
    '# HELP guigui_http_route_requests_total HTTP requests by route.',
    '# TYPE guigui_http_route_requests_total counter',
  ];
  for (const [route, metrics] of routes) {
    const label = route.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    lines.push(`guigui_http_route_requests_total{route="${label}"} ${metrics.count}`);
  }
  if (database) {
    lines.push(
      '# HELP guigui_persistent_requests_total Requests persisted in PostgreSQL for the current day.',
      '# TYPE guigui_persistent_requests_total gauge',
      `guigui_persistent_requests_total ${database.requests}`,
      '# HELP guigui_persistent_errors_total Errors persisted in PostgreSQL for the current day.',
      '# TYPE guigui_persistent_errors_total gauge',
      `guigui_persistent_errors_total ${database.errors}`,
    );
  }
  return `${lines.join('\n')}\n`;
}
